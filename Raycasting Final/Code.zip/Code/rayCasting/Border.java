/*
2020-05-21
Lukas Jonca 
Version 1
the borde4r class is used to house border aka wall variables
 */

//import packages
package rayCasting;

import java.io.Serializable;

public class Border extends Line{
	
	
	//constructor method for borders
	Border(int x1, int y1, int x2, int y2){
		
		//set coordinates
		X1 = x1;
		X2 = x2;
		Y1 = y1;
		Y2 = y2;
	}
	
	
}
